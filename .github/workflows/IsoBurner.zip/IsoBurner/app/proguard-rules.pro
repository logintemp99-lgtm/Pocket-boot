# IsoBurner R8 rules.
# AndroidX, Compose and coroutines ship their own consumer rules; this is only a safety net
# so the ViewModel can always be created by its (Application) constructor.
-keepclassmembers class * extends androidx.lifecycle.AndroidViewModel {
    <init>(android.app.Application);
}
