package com.pocketboot.app

import android.net.Uri
import java.util.Locale

data class DriveItem(
    val id: String,
    val name: String,
    val hasPermission: Boolean,
    val capacityBytes: Long?,
    val error: String?,
)

data class RufusConfig(
    // Boot selection & Image options
    val bootSelection: String = BOOT_ISO,
    val imageOption: String = IMAGE_STANDARD,
    val persistenceGb: Int = 0,

    // Partition scheme & Target system
    val partitionScheme: String = SCHEME_MBR,
    val targetSystem: String = TARGET_BIOS_UEFI_CSM,

    // Advanced drive properties
    val showAdvancedDriveProps: Boolean = false,
    val listUsbHardDrives: Boolean = false,
    val addFixesForOldBios: Boolean = false,
    val useRufusMbr: Boolean = true,
    val biosId: String = "0x80 (Default)",

    // Format options
    val volumeLabel: String = "ISOBURNER",
    val fileSystem: String = FS_FAT32,
    val clusterSize: String = CLUSTER_4096,

    // Advanced format options
    val showAdvancedFormatOptions: Boolean = false,
    val quickFormat: Boolean = true,
    val createExtendedLabel: Boolean = true,
    val checkBadBlocks: Boolean = false,
    val badBlockPasses: String = "1 pass",
) {
    companion object {
        const val BOOT_ISO = "Disk or ISO image"
        const val BOOT_FREEDOS = "FreeDOS"
        const val BOOT_NON_BOOTABLE = "Non bootable"

        const val IMAGE_STANDARD = "Standard ISO installation"
        const val IMAGE_DD = "DD Image (Bit-for-bit)"
        const val IMAGE_WINDOWS_TO_GO = "Windows To Go"

        const val SCHEME_MBR = "MBR"
        const val SCHEME_GPT = "GPT"

        const val TARGET_BIOS_UEFI_CSM = "BIOS (or UEFI-CSM)"
        const val TARGET_UEFI_NON_CSM = "UEFI (non CSM)"
        const val TARGET_BIOS_OR_UEFI = "BIOS or UEFI"

        const val FS_FAT32 = "FAT32 (Default)"
        const val FS_NTFS = "NTFS"
        const val FS_UDF = "UDF"
        const val FS_EXFAT = "exFAT"
        const val FS_LARGE_FAT32 = "Large FAT32"
        const val FS_EXT4 = "ext4"

        const val CLUSTER_4096 = "4096 bytes (Default)"
        const val CLUSTER_8192 = "8192 bytes"
        const val CLUSTER_16K = "16 kilobytes"
        const val CLUSTER_32K = "32 kilobytes"
        const val CLUSTER_64K = "64 kilobytes"

        val bootSelections = listOf(BOOT_ISO, BOOT_FREEDOS, BOOT_NON_BOOTABLE)
        val imageOptions = listOf(IMAGE_STANDARD, IMAGE_DD, IMAGE_WINDOWS_TO_GO)
        val partitionSchemes = listOf(SCHEME_MBR, SCHEME_GPT)
        val targetSystems = listOf(TARGET_BIOS_UEFI_CSM, TARGET_UEFI_NON_CSM, TARGET_BIOS_OR_UEFI)
        val biosIds = listOf("0x80 (Default)", "0x81", "0x82", "0x83")
        val fileSystems = listOf(FS_FAT32, FS_NTFS, FS_UDF, FS_EXFAT, FS_LARGE_FAT32, FS_EXT4)
        val clusterSizes = listOf(CLUSTER_4096, CLUSTER_8192, CLUSTER_16K, CLUSTER_32K, CLUSTER_64K)
        val badBlockPassList = listOf("1 pass", "2 passes", "3 passes", "4 passes")
    }
}

sealed interface WriteState {
    data object Idle : WriteState
    data class Running(
        val writtenBytes: Long,
        val totalBytes: Long,
        val bytesPerSecond: Long,
        val currentItem: String,
    ) : WriteState
    data object Success : WriteState
    data class Failed(val message: String) : WriteState
    data object Cancelled : WriteState
}

data class UiState(
    val drives: List<DriveItem> = emptyList(),
    val selectedDriveId: String? = null,
    val iso: IsoInfo? = null,
    val isoUri: Uri? = null,
    val isoNote: String? = null,
    val config: RufusConfig = RufusConfig(),
    val showConfirm: Boolean = false,
    val showLogs: Boolean = false,
) {
    val selectedDrive: DriveItem?
        get() = drives.firstOrNull { it.id == selectedDriveId }

    /** Why the START button is disabled (null = ready to go). */
    val blocker: String?
        get() {
            val drive = selectedDrive ?: return "Plug in a USB drive to begin"
            if (!drive.hasPermission) return "Tap Allow to give IsoBurner access to the drive"
            val capacity = drive.capacityBytes ?: return drive.error ?: "Reading the drive…"
            if (config.bootSelection == RufusConfig.BOOT_ISO) {
                val image = iso ?: return "Choose an ISO or disk image file"
                if (image.size > capacity) return "The drive is too small for this ISO"
            }
            return null
        }
}

fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var index = -1
    do {
        value /= 1024.0
        index++
    } while (value >= 1024.0 && index < units.lastIndex)
    return String.format(Locale.US, "%.1f %s", value, units[index])
}

fun formatDuration(seconds: Long): String {
    val m = seconds / 60
    val s = seconds % 60
    return String.format(Locale.US, "%d:%02d", m, s)
}
