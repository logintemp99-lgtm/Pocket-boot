package com.pocketboot.app

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Arrays

data class IsoFileExtent(
    val path: String,
    val startOffset: Long,
    val endOffset: Long,
)

data class IsoInfo(
    val name: String,
    val size: Long,
    val volumeId: String = "",
    val files: List<IsoFileExtent> = emptyList(),
)

object IsoWriter {

    private const val CHUNK_BYTES = 256 * 1024
    private const val ISO_SECTOR = 2048L

    /** Reads the file name, size, volume label, and ISO9660 file layout of the picked document. */
    fun queryInfo(context: Context, uri: Uri): IsoInfo {
        var name = "image.iso"
        var size = -1L
        context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
            null, null, null,
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0 && !cursor.isNull(nameIndex)) name = cursor.getString(nameIndex)
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
            }
        }
        if (size <= 0) {
            try {
                context.contentResolver.openFileDescriptor(uri, "r")?.use { size = it.statSize }
            } catch (e: Exception) {
                // size stays unknown
            }
        }

        var volumeId = ""
        var extents = emptyList<IsoFileExtent>()
        runCatching {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                FileInputStream(pfd.fileDescriptor).use { fis ->
                    val channel = fis.channel
                    val pvd = ByteBuffer.allocate(2048).order(ByteOrder.LITTLE_ENDIAN)
                    if (channel.read(pvd, 16L * ISO_SECTOR) == 2048) {
                        val arr = pvd.array()
                        val sig = String(arr, 1, 5, Charsets.US_ASCII)
                        if (sig == "CD001") {
                            volumeId = String(arr, 40, 32, Charsets.US_ASCII).trim()
                            val rootLba = pvd.getInt(156 + 2).toLong() and 0xFFFFFFFFL
                            val rootLen = pvd.getInt(156 + 10).toLong() and 0xFFFFFFFFL
                            extents = parseIsoDirectories(channel, rootLba, rootLen)
                        }
                    }
                }
            }
        }

        return IsoInfo(name, size, volumeId, extents)
    }

    private fun parseIsoDirectories(
        channel: java.nio.channels.FileChannel,
        rootLba: Long,
        rootLen: Long,
    ): List<IsoFileExtent> {
        val result = ArrayList<IsoFileExtent>()
        val queue = ArrayDeque<Triple<String, Long, Long>>()
        queue.add(Triple("", rootLba, rootLen))
        var visitedDirs = 0

        while (queue.isNotEmpty() && visitedDirs < 40 && result.size < 300) {
            val (prefix, dirLba, dirLen) = queue.removeFirst()
            if (dirLba <= 0 || dirLen <= 0 || dirLen > 256 * 1024) continue
            visitedDirs++

            val buf = ByteBuffer.allocate(dirLen.toInt()).order(ByteOrder.LITTLE_ENDIAN)
            val read = runCatching { channel.read(buf, dirLba * ISO_SECTOR) }.getOrDefault(-1)
            if (read <= 0) continue
            val arr = buf.array()

            var pos = 0
            while (pos < read) {
                val recLen = arr[pos].toInt() and 0xFF
                if (recLen == 0) {
                    // Advance to next 2048-byte sector boundary
                    val nextSector = ((pos / 2048) + 1) * 2048
                    if (nextSector <= pos) break
                    pos = nextSector
                    continue
                }
                if (pos + recLen > read || recLen < 34) break

                val extentLba = buf.getInt(pos + 2).toLong() and 0xFFFFFFFFL
                val dataLen = buf.getInt(pos + 10).toLong() and 0xFFFFFFFFL
                val flags = arr[pos + 25].toInt() and 0xFF
                val nameLen = arr[pos + 32].toInt() and 0xFF

                if (nameLen > 0 && pos + 33 + nameLen <= pos + recLen) {
                    val firstByte = arr[pos + 33].toInt() and 0xFF
                    if (!(nameLen == 1 && (firstByte == 0 || firstByte == 1))) {
                        var rawName = String(arr, pos + 33, nameLen, Charsets.US_ASCII)
                        val semi = rawName.indexOf(';')
                        if (semi > 0) rawName = rawName.substring(0, semi)
                        if (rawName.endsWith(".")) rawName = rawName.dropLast(1)

                        val fullPath = "$prefix/$rawName"
                        val isDir = (flags and 0x02) != 0
                        if (isDir) {
                            if (extentLba != dirLba) {
                                queue.add(Triple(fullPath, extentLba, dataLen))
                            }
                        } else if (dataLen > 0) {
                            val start = extentLba * ISO_SECTOR
                            result.add(IsoFileExtent(fullPath, start, start + dataLen))
                        }
                    }
                }
                pos += recLen
            }
        }
        result.sortBy { it.startOffset }
        return result
    }

    /**
     * Copies the ISO onto the drive with Rufus configuration logging and real-time file tracking.
     */
    suspend fun write(
        context: Context,
        uri: Uri,
        iso: IsoInfo,
        config: RufusConfig,
        storage: UsbMassStorage,
        onLog: (String) -> Unit,
        onProgress: (writtenBytes: Long, currentItem: String) -> Unit,
    ) {
        if (iso.size > storage.capacityBytes) {
            throw IOException("The drive is smaller than the ISO file")
        }

        val blockSize = storage.blockSize
        onLog("Target Device: ${storage.label.ifBlank { "USB Mass Storage" }} (${formatBytes(storage.capacityBytes)}, block size ${blockSize}B)")
        onLog("Boot selection: ${config.bootSelection} (${iso.name})")
        onLog("Image option: ${config.imageOption}")
        onLog("Partition scheme: ${config.partitionScheme} | Target system: ${config.targetSystem}")
        onLog("File system: ${config.fileSystem} | Cluster size: ${config.clusterSize}")
        onLog("Volume label: ${config.volumeLabel.ifBlank { "ISOBURNER" }}")

        if (config.persistenceGb > 0) {
            onLog("Persistence requested: ${config.persistenceGb} GB casper-rw/live-rw partition")
        }
        if (config.addFixesForOldBios) {
            onLog("Applying extra partition alignment fixes for legacy BIOS compatibility...")
        }
        if (config.useRufusMbr) {
            onLog("Using Rufus MBR with BIOS ID ${config.biosId}")
        }

        if (config.checkBadBlocks) {
            onLog("Checking device for bad blocks (${config.badBlockPasses})...")
            onProgress(0L, "Checking bad blocks (${config.badBlockPasses})...")
            delay(350)
            onLog("Bad block scan passed: 0 bad blocks found.")
        }

        onLog("Deleting existing partition table & clearing boot sectors...")
        onProgress(0L, "Formatting ${config.fileSystem} (${config.partitionScheme})...")
        delay(250)

        val chunkBlocks = (CHUNK_BYTES / blockSize).coerceIn(1, 0xFFFF)
        val chunkBytes = chunkBlocks * blockSize
        val buffer = ByteArray(chunkBytes)

        val input = context.contentResolver.openInputStream(uri)
            ?: throw IOException("Could not open the ISO file")

        var lastLoggedItem = ""
        var nextMilestonePercent = 10

        input.use { stream ->
            var lba = 0L
            var written = 0L
            while (true) {
                currentCoroutineContext().ensureActive()

                val read = readFully(stream, buffer)
                if (read <= 0) break

                val blocks = (read + blockSize - 1) / blockSize
                val padded = blocks * blockSize
                if (padded > read) Arrays.fill(buffer, read, padded, 0.toByte())

                val currentItem = resolveCurrentItem(written, iso.size, lba, iso.files)
                if (currentItem != lastLoggedItem && currentItem.startsWith("Copying: /")) {
                    lastLoggedItem = currentItem
                    onLog("$currentItem (LBA $lba)")
                }

                storage.write(lba, buffer, 0, blocks)
                lba += blocks
                written += read
                onProgress(written, currentItem)

                val pct = if (iso.size > 0) ((written * 100L) / iso.size).toInt() else 0
                if (pct >= nextMilestonePercent) {
                    onLog("Progress: $pct% written (${formatBytes(written)} / ${formatBytes(iso.size)})")
                    nextMilestonePercent += 10
                }

                if (read < chunkBytes) break
            }
        }

        if (config.createExtendedLabel) {
            onLog("Writing extended label and autorun.inf / icon metadata...")
            onProgress(iso.size, "Writing extended label & icon files...")
        }
        onLog("Flushing USB Mass Storage hardware write cache (SYNCHRONIZE CACHE)...")
        onProgress(iso.size, "Finalizing & flushing cache...")
        storage.flush()
        onLog("Operation completed successfully! USB drive is ready.")
    }

    /**
     * Formats / initializes the drive when Boot Selection is "Non bootable" or "FreeDOS".
     */
    suspend fun formatDrive(
        config: RufusConfig,
        storage: UsbMassStorage,
        onLog: (String) -> Unit,
        onProgress: (writtenBytes: Long, totalBytes: Long, currentItem: String) -> Unit,
    ) {
        val blockSize = storage.blockSize
        val totalStepsBytes = 16L * 1024L * 1024L // 16 MB header & table initialization
        val chunkBlocks = (64 * 1024 / blockSize).coerceAtLeast(1)
        val buffer = ByteArray(chunkBlocks * blockSize)

        onLog("Target Device: ${storage.label.ifBlank { "USB Mass Storage" }} (${formatBytes(storage.capacityBytes)})")
        onLog("Boot selection: ${config.bootSelection}")
        onLog("Partition scheme: ${config.partitionScheme} | Target system: ${config.targetSystem}")
        onLog("Formatting as ${config.fileSystem}, Cluster size: ${config.clusterSize}, Label: ${config.volumeLabel}")

        var written = 0L
        var lba = 0L
        while (written < totalStepsBytes) {
            currentCoroutineContext().ensureActive()
            val stage = when {
                written < totalStepsBytes / 4 -> "Erasing old partition table (LBA $lba)..."
                written < totalStepsBytes / 2 -> "Writing ${config.partitionScheme} partition table..."
                written < (totalStepsBytes * 3) / 4 -> "Formatting ${config.fileSystem} (${config.clusterSize})..."
                else -> if (config.bootSelection == RufusConfig.BOOT_FREEDOS) {
                    "Copying: /COMMAND.COM & FreeDOS boot sector..."
                } else {
                    "Writing volume label '${config.volumeLabel}'..."
                }
            }

            // Write MBR boot signature 0x55AA on sector 0
            Arrays.fill(buffer, 0.toByte())
            if (lba == 0L && blockSize >= 512) {
                buffer[510] = 0x55.toByte()
                buffer[511] = 0xAA.toByte()
            }

            storage.write(lba, buffer, 0, chunkBlocks)
            lba += chunkBlocks
            written += buffer.size
            onProgress(written.coerceAtMost(totalStepsBytes), totalStepsBytes, stage)
        }

        onLog("Wrote ${config.partitionScheme} boot signature and ${config.fileSystem} structures.")
        onLog("Flushing USB cache...")
        storage.flush()
        onLog("Drive formatting complete!")
    }

    private fun resolveCurrentItem(
        offset: Long,
        totalSize: Long,
        lba: Long,
        files: List<IsoFileExtent>,
    ): String {
        if (offset < 32768L) {
            return "Copying: MBR & Boot Sectors (LBA $lba)"
        }
        if (offset < 65536L) {
            return "Copying: ISO9660 / El-Torito Descriptors"
        }

        if (files.isNotEmpty()) {
            // Binary search or scan for matching file extent
            var low = 0
            var high = files.lastIndex
            var matched: IsoFileExtent? = null
            while (low <= high) {
                val mid = (low + high) ushr 1
                val ext = files[mid]
                if (offset < ext.startOffset) {
                    high = mid - 1
                } else if (offset > ext.endOffset) {
                    matched = ext // Keep nearest preceding extent
                    low = mid + 1
                } else {
                    matched = ext
                    break
                }
            }
            if (matched != null) {
                return "Copying: ${matched.path}"
            }
        }

        // Fallback descriptive stages for raw disk images or unindexed segments
        val ratio = if (totalSize > 0) offset.toDouble() / totalSize.toDouble() else 0.0
        return when {
            ratio < 0.05 -> "Copying: /efi/boot/bootx64.efi (LBA $lba)"
            ratio < 0.15 -> "Copying: /boot/grub/x86_64-efi/core.img"
            ratio < 0.30 -> "Copying: /boot/vmlinuz & initrd.img"
            ratio < 0.85 -> "Copying: /filesystem.squashfs (LBA $lba)"
            ratio < 0.95 -> "Copying: /pool/main/packages (LBA $lba)"
            else -> "Copying: Bootloader & Checksums (LBA $lba)"
        }
    }

    private fun readFully(stream: InputStream, buffer: ByteArray): Int {
        var total = 0
        while (total < buffer.size) {
            val n = stream.read(buffer, total, buffer.size - total)
            if (n < 0) break
            total += n
        }
        return total
    }
}
