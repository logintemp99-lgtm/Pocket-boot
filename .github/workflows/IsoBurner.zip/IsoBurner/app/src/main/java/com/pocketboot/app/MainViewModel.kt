package com.pocketboot.app

import android.app.Application
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val usbManager = application.getSystemService(Context.USB_SERVICE) as UsbManager

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    // Log lines and write progress change very often, so they live in their own flows.
    // Only the log card and the progress card listen to them; the rest of the screen stays untouched.
    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs.asStateFlow()

    private val _write = MutableStateFlow<WriteState>(WriteState.Idle)
    val writeState: StateFlow<WriteState> = _write.asStateFlow()

    /** True only while a write is running (flips twice per write, unlike the progress itself). */
    val busy: StateFlow<Boolean> = _write
        .map { it is WriteState.Running }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    private class Probe(
        val capacity: Long?,
        val label: String?,
        val error: String?,
        val at: Long,
    )

    private val probes = ConcurrentHashMap<String, Probe>()
    private val permissionAsked: MutableSet<String> = ConcurrentHashMap.newKeySet<String>()
    private val loggedDrives: MutableSet<String> = ConcurrentHashMap.newKeySet<String>()
    private val usbLock = Mutex()
    private var writeJob: Job? = null
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)

    init {
        appendLog("IsoBurner v1.1.0 — Rufus Configuration Engine initialized")
        appendLog("Host OS: Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) | Arch: ${Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64"}")
        appendLog("USB Host Bulk-Only Transport (BOT) SCSI driver ready.")
    }

    fun appendLog(message: String) {
        val stamp = synchronized(timeFormat) { timeFormat.format(Date()) }
        val line = "[$stamp] $message"
        _logs.update { old ->
            // One copy instead of two, and never more than MAX_LOG_LINES kept.
            val from = (old.size + 1 - MAX_LOG_LINES).coerceAtLeast(0)
            val next = ArrayList<String>(old.size - from + 1)
            for (i in from until old.size) next.add(old[i])
            next.add(line)
            next
        }
    }

    fun toggleLogs() {
        _state.update { it.copy(showLogs = !it.showLogs) }
    }

    fun clearLogs() {
        _logs.value = emptyList()
        appendLog("Log cleared by user.")
    }

    // ------------------------------------------------------------ Rufus Config Updaters

    fun updateConfig(transform: (RufusConfig) -> RufusConfig, logMsg: String? = null) {
        _state.update { s -> s.copy(config = transform(s.config)) }
        if (logMsg != null) appendLog(logMsg)
    }

    fun setBootSelection(value: String) {
        updateConfig(
            transform = { it.copy(bootSelection = value) },
            logMsg = "Boot selection changed to: $value",
        )
    }

    fun setImageOption(value: String) {
        updateConfig(
            transform = { it.copy(imageOption = value) },
            logMsg = "Image option set to: $value",
        )
    }

    fun setPersistenceGb(gb: Int) {
        updateConfig(
            transform = { it.copy(persistenceGb = gb) },
            logMsg = if (gb == 0) "Persistent partition disabled (0 GB)" else "Persistent partition size set to $gb GB",
        )
    }

    fun setPartitionScheme(scheme: String) {
        val autoTarget = if (scheme == RufusConfig.SCHEME_GPT) {
            RufusConfig.TARGET_UEFI_NON_CSM
        } else {
            RufusConfig.TARGET_BIOS_UEFI_CSM
        }
        updateConfig(
            transform = { it.copy(partitionScheme = scheme, targetSystem = autoTarget) },
            logMsg = "Partition scheme set to $scheme (Target system: $autoTarget)",
        )
    }

    fun setTargetSystem(target: String) {
        updateConfig(
            transform = { it.copy(targetSystem = target) },
            logMsg = "Target system set to: $target",
        )
    }

    fun toggleAdvancedDriveProps() {
        updateConfig(transform = { it.copy(showAdvancedDriveProps = !it.showAdvancedDriveProps) })
    }

    fun setListUsbHardDrives(enabled: Boolean) {
        updateConfig(
            transform = { it.copy(listUsbHardDrives = enabled) },
            logMsg = "List USB Hard Drives: $enabled",
        )
    }

    fun setAddFixesForOldBios(enabled: Boolean) {
        updateConfig(
            transform = { it.copy(addFixesForOldBios = enabled) },
            logMsg = "Add fixes for old BIOSes: $enabled",
        )
    }

    fun setUseRufusMbr(enabled: Boolean) {
        updateConfig(
            transform = { it.copy(useRufusMbr = enabled) },
            logMsg = "Use Rufus MBR with BIOS ID: $enabled",
        )
    }

    fun setBiosId(id: String) {
        updateConfig(
            transform = { it.copy(biosId = id) },
            logMsg = "Rufus MBR BIOS ID set to: $id",
        )
    }

    fun setVolumeLabel(label: String) {
        updateConfig(transform = { it.copy(volumeLabel = label) })
    }

    fun setFileSystem(fs: String) {
        updateConfig(
            transform = { it.copy(fileSystem = fs) },
            logMsg = "File system set to: $fs",
        )
    }

    fun setClusterSize(size: String) {
        updateConfig(
            transform = { it.copy(clusterSize = size) },
            logMsg = "Cluster size set to: $size",
        )
    }

    fun toggleAdvancedFormatOptions() {
        updateConfig(transform = { it.copy(showAdvancedFormatOptions = !it.showAdvancedFormatOptions) })
    }

    fun setQuickFormat(enabled: Boolean) {
        updateConfig(
            transform = { it.copy(quickFormat = enabled) },
            logMsg = "Quick format: $enabled",
        )
    }

    fun setCreateExtendedLabel(enabled: Boolean) {
        updateConfig(
            transform = { it.copy(createExtendedLabel = enabled) },
            logMsg = "Create extended label and icon files: $enabled",
        )
    }

    fun setCheckBadBlocks(enabled: Boolean) {
        updateConfig(
            transform = { it.copy(checkBadBlocks = enabled) },
            logMsg = "Check device for bad blocks: $enabled",
        )
    }

    fun setBadBlockPasses(passes: String) {
        updateConfig(
            transform = { it.copy(badBlockPasses = passes) },
            logMsg = "Bad block check passes: $passes",
        )
    }

    // ------------------------------------------------------------ drive detection

    /** Called every second or so while the app is on screen. Runs off the main thread. */
    suspend fun refreshDrives() {
        try {
            withContext(Dispatchers.IO) {
                val devices = usbManager.deviceList.values.filter { UsbMassStorage.isMassStorage(it) }
                val ids = devices.map { it.deviceName }.toSet()
                probes.keys.retainAll(ids)
                permissionAsked.retainAll(ids)
                loggedDrives.retainAll(ids)

                val writing = _write.value is WriteState.Running
                val items = ArrayList<DriveItem>()
                for (device in devices) {
                    val id = device.deviceName
                    val permitted = usbManager.hasPermission(device)
                    if (!permitted && permissionAsked.add(id)) {
                        appendLog("USB device attached ($id). Requesting USB host permission...")
                        requestPermission(device)
                    }

                    if (permitted && !writing) {
                        val old = probes[id]
                        val stale = old == null ||
                            (old.error != null && SystemClock.elapsedRealtime() - old.at > 4_000)
                        if (stale) {
                            val probed = usbLock.withLock { probe(device) }
                            probes[id] = probed
                            if (probed.capacity != null && loggedDrives.add(id)) {
                                appendLog("Found USB drive: ${driveName(device, probed)} (${formatBytes(probed.capacity)})")
                            } else if (probed.error != null && loggedDrives.add("$id-err")) {
                                appendLog("Drive probe note ($id): ${probed.error}")
                            }
                        }
                    }
                    val p = probes[id]
                    items.add(DriveItem(id, driveName(device, p), permitted, p?.capacity, p?.error))
                }

                _state.update { s ->
                    val selected =
                        if (items.any { it.id == s.selectedDriveId }) s.selectedDriveId
                        else items.firstOrNull()?.id
                    if (s.drives == items && s.selectedDriveId == selected) s
                    else s.copy(drives = items, selectedDriveId = selected)
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // Never let a USB hiccup crash the polling loop.
        }
    }

    private fun probe(device: UsbDevice): Probe {
        return try {
            UsbMassStorage.open(usbManager, device).use {
                Probe(it.capacityBytes, it.label, null, SystemClock.elapsedRealtime())
            }
        } catch (e: Exception) {
            Probe(null, null, e.message ?: "Could not read the drive", SystemClock.elapsedRealtime())
        }
    }

    private fun driveName(device: UsbDevice, probe: Probe?): String {
        val scsi = probe?.label?.takeIf { it.isNotBlank() }
        if (scsi != null) return scsi
        val product = runCatching { device.productName }.getOrNull()?.takeIf { it.isNotBlank() }
        return product ?: "USB Drive"
    }

    private fun requestPermission(device: UsbDevice) {
        val app = getApplication<Application>()
        val intent = Intent(ACTION_USB_PERMISSION).setPackage(app.packageName)
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
        val pending = PendingIntent.getBroadcast(app, 0, intent, flags)
        usbManager.requestPermission(device, pending)
    }

    /** The "Allow" button: ask Android for access to the drive again. */
    fun grantAccess(driveId: String) {
        val device = usbManager.deviceList.values.firstOrNull { it.deviceName == driveId } ?: return
        appendLog("Requesting USB permission for device $driveId...")
        requestPermission(device)
    }

    fun selectDrive(id: String) {
        _state.update { it.copy(selectedDriveId = id) }
        val name = _state.value.drives.firstOrNull { it.id == id }?.name ?: id
        appendLog("Selected target USB device: $name")
    }

    // ------------------------------------------------------------ ISO picking

    fun onIsoPicked(uri: Uri) {
        viewModelScope.launch {
            appendLog("Scanning selected image file...")
            val info = withContext(Dispatchers.IO) {
                runCatching { IsoWriter.queryInfo(getApplication(), uri) }.getOrNull()
            }
            if (info == null || info.size <= 0) {
                appendLog("Error: Could not read image size or descriptor.")
                _state.update { s ->
                    s.copy(
                        iso = null,
                        isoUri = null,
                        isoNote = "Couldn't read this file. Try picking it from your Downloads folder.",
                    )
                }
            } else {
                val lower = info.name.lowercase()
                val looksRight = lower.endsWith(".iso") || lower.endsWith(".img") || lower.endsWith(".bin")
                val suggestedLabel = info.volumeId.ifBlank {
                    info.name.substringBeforeLast('.')
                        .uppercase(Locale.US)
                        .replace(Regex("[^A-Z0-9_-]"), "_")
                        .take(16)
                        .ifBlank { "ISOBURNER" }
                }
                appendLog("Loaded image: ${info.name} (${formatBytes(info.size)})")
                if (info.volumeId.isNotBlank()) {
                    appendLog("Detected ISO9660 Volume ID: '${info.volumeId}' (${info.files.size} boot/system files indexed)")
                } else {
                    appendLog("Image type: Raw/Hybrid disk image (Volume label set to '$suggestedLabel')")
                }
                _state.update { s ->
                    s.copy(
                        iso = info,
                        isoUri = uri,
                        isoNote = if (looksRight) null else "This doesn't look like an .iso/.img file. Double-check it.",
                        config = s.config.copy(
                            bootSelection = RufusConfig.BOOT_ISO,
                            volumeLabel = suggestedLabel,
                        ),
                    )
                }
            }
        }
    }

    // ------------------------------------------------------------ writing

    fun requestStart() {
        if (_state.value.blocker == null) {
            appendLog("Waiting for user confirmation to format and erase target drive...")
            _state.update { it.copy(showConfirm = true) }
        }
    }

    fun dismissConfirm() {
        appendLog("Operation cancelled at confirmation prompt.")
        _state.update { it.copy(showConfirm = false) }
    }

    fun confirmStart() {
        appendLog("User confirmed drive erasure. Starting operation...")
        _state.update { it.copy(showConfirm = false) }
        startWriting()
    }

    fun cancelWriting() {
        appendLog("Cancellation requested by user! Stopping write job...")
        writeJob?.cancel()
    }

    fun resetResult() {
        _write.value = WriteState.Idle
    }

    private fun startWriting() {
        val s = _state.value
        val drive = s.selectedDrive ?: return
        val cfg = s.config
        val device = usbManager.deviceList.values.firstOrNull { it.deviceName == drive.id }
        if (device == null) {
            appendLog("Error: Target USB drive was unplugged before write started.")
            _write.value = WriteState.Failed("The drive was unplugged.")
            return
        }

        if (cfg.bootSelection != RufusConfig.BOOT_ISO) {
            // Non-bootable or FreeDOS format mode
            val totalFormatBytes = 16L * 1024L * 1024L
            writeJob = viewModelScope.launch {
                _write.value = WriteState.Running(
                    writtenBytes = 0L,
                    totalBytes = totalFormatBytes,
                    bytesPerSecond = 0L,
                    currentItem = "Formatting ${cfg.fileSystem} (${cfg.partitionScheme})...",
                )
                try {
                    withContext(Dispatchers.IO) {
                        usbLock.withLock {
                            UsbMassStorage.open(usbManager, device).use { storage ->
                                IsoWriter.formatDrive(
                                    config = cfg,
                                    storage = storage,
                                    onLog = { msg -> appendLog(msg) },
                                    onProgress = { written, total, item ->
                                        _write.value = WriteState.Running(
                                            writtenBytes = written,
                                            totalBytes = total,
                                            bytesPerSecond = 8L * 1024L * 1024L,
                                            currentItem = item,
                                        )
                                    },
                                )
                            }
                        }
                    }
                    _write.value = WriteState.Success
                } catch (e: CancellationException) {
                    appendLog("Format operation cancelled.")
                    _write.value = WriteState.Cancelled
                    throw e
                } catch (e: Exception) {
                    val err = friendly(e)
                    appendLog("Error: $err")
                    _write.value = WriteState.Failed(err)
                } finally {
                    probes.remove(drive.id)
                }
            }
            return
        }

        val iso = s.iso ?: return
        val uri = s.isoUri ?: return

        writeJob = viewModelScope.launch {
            _write.value = WriteState.Running(
                writtenBytes = 0L,
                totalBytes = iso.size,
                bytesPerSecond = 0L,
                currentItem = "Preparing ${cfg.partitionScheme} / ${cfg.fileSystem}...",
            )
            try {
                withContext(Dispatchers.IO) {
                    usbLock.withLock {
                        UsbMassStorage.open(usbManager, device).use { storage ->
                            var lastUiUpdate = 0L
                            var speedTime = SystemClock.elapsedRealtime()
                            var speedBytes = 0L
                            var speed = 0L
                            IsoWriter.write(
                                context = getApplication(),
                                uri = uri,
                                iso = iso,
                                config = cfg,
                                storage = storage,
                                onLog = { msg -> appendLog(msg) },
                                onProgress = { written, currentItem ->
                                    val now = SystemClock.elapsedRealtime()
                                    if (now - speedTime >= 1000) {
                                        speed = (written - speedBytes) * 1000 / (now - speedTime)
                                        speedBytes = written
                                        speedTime = now
                                    }
                                    if (now - lastUiUpdate >= 200 || written >= iso.size) {
                                        lastUiUpdate = now
                                        _write.value = WriteState.Running(
                                            writtenBytes = written,
                                            totalBytes = iso.size,
                                            bytesPerSecond = speed,
                                            currentItem = currentItem,
                                        )
                                    }
                                },
                            )
                        }
                    }
                }
                _write.value = WriteState.Success
            } catch (e: CancellationException) {
                appendLog("Write operation cancelled by user.")
                _write.value = WriteState.Cancelled
                throw e
            } catch (e: Exception) {
                val err = friendly(e)
                appendLog("Write failed: $err")
                _write.value = WriteState.Failed(err)
            } finally {
                probes.remove(drive.id) // re-read the drive afterwards
            }
        }
    }

    private fun friendly(e: Exception): String = when (e) {
        is SecurityException -> "Access to the drive was lost. Unplug it, plug it back in and allow access."
        else -> e.message ?: "Something went wrong while writing."
    }

    private companion object {
        const val ACTION_USB_PERMISSION = "com.pocketboot.app.USB_PERMISSION"
        const val MAX_LOG_LINES = 500
    }
}
