package com.pocketboot.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF4F46E5),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0E7FF),
    onPrimaryContainer = Color(0xFF1E1B4B),
    secondary = Color(0xFF0891B2),
    background = Color(0xFFF4F6FB),
    onBackground = Color(0xFF14183F),
    surface = Color.White,
    onSurface = Color(0xFF14183F),
    surfaceVariant = Color(0xFFEEF1F8),
    onSurfaceVariant = Color(0xFF4B5470),
    error = Color(0xFFD92D20),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9AA2FF),
    onPrimary = Color(0xFF14183F),
    primaryContainer = Color(0xFF2B3170),
    onPrimaryContainer = Color(0xFFE0E4FF),
    secondary = Color(0xFF22D3EE),
    background = Color(0xFF0D1030),
    onBackground = Color(0xFFEDEFFF),
    surface = Color(0xFF161A45),
    onSurface = Color(0xFFEDEFFF),
    surfaceVariant = Color(0xFF1F2457),
    onSurfaceVariant = Color(0xFFB4BAE0),
    error = Color(0xFFFF8A80),
)

@Composable
fun IsoBurnerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content,
    )
}
