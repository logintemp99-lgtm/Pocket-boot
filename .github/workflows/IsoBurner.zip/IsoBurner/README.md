# IsoBurner

Make bootable USB drives from an .iso file, straight from your Android phone (OTG cable required).

- Detects the USB drive automatically
- Writes the ISO block by block (like Rufus "DD image" mode), no root needed
- Works with hybrid ISOs (most Linux distros). Standard Windows ISOs are not supported.

## Build without a PC
1. Put this project (or `IsoBurner.zip`) in a GitHub repository, plus `.github/workflows/build.yml`.
2. Open the **Actions** tab, run **Build Android APK** (it also runs on every push).
3. Download `IsoBurner.apk` from the **Releases** page and install it on your phone.
