package com.pocketboot.app

import android.net.Uri
import java.util.Locale

data class DriveItem(
    val id: String,
    val name: String,
    val hasPermission: Boolean,
    val capacityBytes: Long?,
    val error: String?,
)

sealed interface WriteState {
    data object Idle : WriteState
    data class Running(
        val writtenBytes: Long,
        val totalBytes: Long,
        val bytesPerSecond: Long,
    ) : WriteState
    data object Success : WriteState
    data class Failed(val message: String) : WriteState
    data object Cancelled : WriteState
}

data class UiState(
    val drives: List<DriveItem> = emptyList(),
    val selectedDriveId: String? = null,
    val iso: IsoInfo? = null,
    val isoUri: Uri? = null,
    val isoNote: String? = null,
    val write: WriteState = WriteState.Idle,
    val showConfirm: Boolean = false,
) {
    val selectedDrive: DriveItem?
        get() = drives.firstOrNull { it.id == selectedDriveId }

    /** Why the START button is disabled (null = ready to go). */
    val blocker: String?
        get() {
            val drive = selectedDrive ?: return "Plug in a USB drive to begin"
            if (!drive.hasPermission) return "Tap Allow to give PocketBoot access to the drive"
            val capacity = drive.capacityBytes ?: return drive.error ?: "Reading the drive…"
            val image = iso ?: return "Choose an ISO file"
            if (image.size > capacity) return "The drive is too small for this ISO"
            return null
        }
}

fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var index = -1
    do {
        value /= 1024.0
        index++
    } while (value >= 1024.0 && index < units.lastIndex)
    return String.format(Locale.US, "%.1f %s", value, units[index])
}

fun formatDuration(seconds: Long): String {
    val m = seconds / 60
    val s = seconds % 60
    return String.format(Locale.US, "%d:%02d", m, s)
}
