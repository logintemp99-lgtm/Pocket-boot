package com.pocketboot.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pocketboot.app.DriveItem
import com.pocketboot.app.R
import com.pocketboot.app.UiState
import com.pocketboot.app.WriteState
import com.pocketboot.app.formatBytes
import com.pocketboot.app.formatDuration

@Composable
fun MainScreen(
    state: UiState,
    onPickIso: () -> Unit,
    onSelectDrive: (String) -> Unit,
    onGrantAccess: (String) -> Unit,
    onStart: () -> Unit,
    onConfirm: () -> Unit,
    onDismissConfirm: () -> Unit,
    onCancel: () -> Unit,
    onReset: () -> Unit,
) {
    val busy = state.write is WriteState.Running

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Header()
            DriveCard(state, busy, onSelectDrive, onGrantAccess)
            IsoCard(state, busy, onPickIso)
            ActionArea(state, onStart, onCancel, onReset)
            InfoNote()
        }
    }

    if (state.showConfirm) {
        ConfirmDialog(state, onConfirm, onDismissConfirm)
    }
}

// ------------------------------------------------------------------ header

@Composable
private fun Header() {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.padding(vertical = 4.dp),
    ) {
        Box(
            modifier = Modifier
                .size(60.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xFF151A3D)),
            contentAlignment = Alignment.Center,
        ) {
            // The launcher foreground has transparent padding; scale it up so the art fills the badge.
            Image(
                painter = painterResource(R.drawable.ic_launcher_foreground),
                contentDescription = "PocketBoot logo",
                modifier = Modifier.requiredSize(94.dp),
            )
        }
        Column {
            Text(
                "PocketBoot",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold,
            )
            Text(
                "Bootable USB drives, right from your phone",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

// ------------------------------------------------------------------ cards

@Composable
private fun StepCard(step: String, title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        step,
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                    )
                }
                Spacer(Modifier.width(10.dp))
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            content()
        }
    }
}

@Composable
private fun DriveCard(
    state: UiState,
    busy: Boolean,
    onSelect: (String) -> Unit,
    onGrant: (String) -> Unit,
) {
    StepCard("1", "USB drive") {
        if (state.drives.isEmpty()) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text("🔌", fontSize = 30.sp)
                Column(Modifier.weight(1f)) {
                    Text(
                        "No drive detected",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        "Plug a USB drive into your phone with an OTG cable. It appears here automatically.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
            }
        } else {
            state.drives.forEach { drive ->
                DriveRow(
                    drive = drive,
                    selected = drive.id == state.selectedDriveId,
                    showRadio = state.drives.size > 1,
                    enabled = !busy,
                    onSelect = onSelect,
                    onGrant = onGrant,
                )
            }
        }
    }
}

@Composable
private fun DriveRow(
    drive: DriveItem,
    selected: Boolean,
    showRadio: Boolean,
    enabled: Boolean,
    onSelect: (String) -> Unit,
    onGrant: (String) -> Unit,
) {
    val background =
        if (selected) MaterialTheme.colorScheme.primaryContainer
        else MaterialTheme.colorScheme.surfaceVariant
    val capacity = drive.capacityBytes
    val subtitle = when {
        !drive.hasPermission -> "Allow access to continue"
        capacity != null -> formatBytes(capacity)
        drive.error != null -> drive.error
        else -> "Reading drive…"
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(background)
            .clickable(enabled = enabled) { onSelect(drive.id) }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("💾", fontSize = 28.sp)
        Column(Modifier.weight(1f)) {
            Text(
                drive.name,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = if (drive.error != null && capacity == null) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (!drive.hasPermission) {
            TextButton(onClick = { onGrant(drive.id) }) { Text("Allow") }
        } else if (showRadio) {
            RadioButton(selected = selected, onClick = null)
        }
    }
}

@Composable
private fun IsoCard(state: UiState, busy: Boolean, onPick: () -> Unit) {
    val iso = state.iso
    StepCard("2", "ISO image") {
        if (iso == null) {
            FilledTonalButton(
                onClick = onPick,
                enabled = !busy,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
            ) {
                Text("💿  Choose .iso file", fontSize = 16.sp)
            }
        } else {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(14.dp),
            ) {
                Text("💿", fontSize = 28.sp)
                Column(Modifier.weight(1f)) {
                    Text(
                        iso.name,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        formatBytes(iso.size),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                TextButton(onClick = onPick, enabled = !busy) { Text("Change") }
            }
        }
        state.isoNote?.let {
            Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        }
    }
}

// ------------------------------------------------------------------ start / progress / result

@Composable
private fun ActionArea(
    state: UiState,
    onStart: () -> Unit,
    onCancel: () -> Unit,
    onReset: () -> Unit,
) {
    when (val write = state.write) {
        is WriteState.Running -> ProgressCard(write, onCancel)
        is WriteState.Success -> ResultCard(
            emoji = "✅",
            title = "Your bootable drive is ready",
            message = "Safely unplug it, then boot your computer from it (open the boot menu when the PC starts).",
            buttonLabel = "Done",
            onClick = onReset,
        )
        is WriteState.Failed -> ResultCard(
            emoji = "⚠️",
            title = "Something went wrong",
            message = write.message,
            buttonLabel = "Back",
            onClick = onReset,
        )
        is WriteState.Cancelled -> ResultCard(
            emoji = "⏹️",
            title = "Cancelled",
            message = "The drive is only partly written and won't boot. Start again to finish.",
            buttonLabel = "OK",
            onClick = onReset,
        )
        is WriteState.Idle -> {
            val blocker = state.blocker
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Button(
                    onClick = onStart,
                    enabled = blocker == null,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp),
                ) {
                    Text("START", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                if (blocker != null) {
                    Text(
                        blocker,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                    )
                }
            }
        }
    }
}

@Composable
private fun ProgressCard(write: WriteState.Running, onCancel: () -> Unit) {
    val progress =
        if (write.totalBytes > 0) (write.writtenBytes.toFloat() / write.totalBytes).coerceIn(0f, 1f) else 0f
    val finishing = write.writtenBytes >= write.totalBytes
    val remaining = write.totalBytes - write.writtenBytes
    val eta =
        if (write.bytesPerSecond > 0 && !finishing) " • " + formatDuration(remaining / write.bytesPerSecond) + " left"
        else ""

    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                if (finishing) "Finishing up…" else "Writing… ${(progress * 100).toInt()}%",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp)),
            )
            Text(
                formatBytes(write.writtenBytes) + " of " + formatBytes(write.totalBytes) +
                    " • " + formatBytes(write.bytesPerSecond) + "/s" + eta,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "Keep the app open and the drive plugged in.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedButton(
                onClick = onCancel,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text("Cancel")
            }
        }
    }
}

@Composable
private fun ResultCard(
    emoji: String,
    title: String,
    message: String,
    buttonLabel: String,
    onClick: () -> Unit,
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(emoji, fontSize = 40.sp)
            Text(
                title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                textAlign = TextAlign.Center,
            )
            Text(
                message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                textAlign = TextAlign.Center,
            )
            Button(onClick = onClick, shape = RoundedCornerShape(14.dp)) { Text(buttonLabel) }
        }
    }
}

@Composable
private fun InfoNote() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(14.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("ℹ️", fontSize = 18.sp)
        Text(
            "Works with hybrid ISOs: most Linux distros (Ubuntu, Debian, Fedora, Mint, Kali, Tails…) and many " +
                "rescue tools. Standard Windows ISOs are not supported yet.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

// ------------------------------------------------------------------ confirm dialog

@Composable
private fun ConfirmDialog(state: UiState, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val drive = state.selectedDrive
    val iso = state.iso
    val capacity = drive?.capacityBytes?.let { " (" + formatBytes(it) + ")" } ?: ""
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Erase this drive?") },
        text = {
            Text(
                "Everything on " + (drive?.name ?: "the drive") + capacity +
                    " will be permanently deleted and replaced with " + (iso?.name ?: "the ISO") + ".",
            )
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
            ) {
                Text("Erase & write")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
