package com.pocketboot.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pocketboot.app.DriveItem
import com.pocketboot.app.MainViewModel
import com.pocketboot.app.R
import com.pocketboot.app.RufusConfig
import com.pocketboot.app.UiState
import com.pocketboot.app.WriteState
import com.pocketboot.app.formatBytes
import com.pocketboot.app.formatDuration
import kotlin.math.roundToInt

@Composable
fun MainScreen(
    state: UiState,
    viewModel: MainViewModel,
    onPickIso: () -> Unit,
) {
    val busy = state.write is WriteState.Running

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Header(
                showLogs = state.showLogs,
                onToggleLogs = viewModel::toggleLogs,
            )

            // 1. Drive Properties (Device + Advanced Drive Properties)
            DrivePropertiesCard(
                state = state,
                busy = busy,
                viewModel = viewModel,
            )

            // 2. Boot Selection, Image Options, Partition Scheme & Target System
            BootAndPartitionCard(
                state = state,
                busy = busy,
                viewModel = viewModel,
                onPickIso = onPickIso,
            )

            // 3. Format Options (Volume Label, File System, Cluster Size, Advanced Format Options)
            FormatOptionsCard(
                state = state,
                busy = busy,
                viewModel = viewModel,
            )

            // Live Log Viewer Panel (Toggled via Log button)
            if (state.showLogs) {
                LogViewerCard(
                    logs = state.logs,
                    onClear = viewModel::clearLogs,
                    onClose = viewModel::toggleLogs,
                )
            }

            // Status / Progress Bar & Action Buttons (Log + START)
            ActionArea(
                state = state,
                onStart = viewModel::requestStart,
                onCancel = viewModel::cancelWriting,
                onReset = viewModel::resetResult,
                onToggleLogs = viewModel::toggleLogs,
            )

            InfoNote()
        }
    }

    if (state.showConfirm) {
        ConfirmDialog(
            state = state,
            onConfirm = viewModel::confirmStart,
            onDismiss = viewModel::dismissConfirm,
        )
    }
}

// ------------------------------------------------------------------ header

@Composable
private fun Header(
    showLogs: Boolean,
    onToggleLogs: () -> Unit,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF151A3D)),
            contentAlignment = Alignment.Center,
        ) {
            Image(
                painter = painterResource(R.drawable.ic_launcher_foreground),
                contentDescription = "PocketBoot logo",
                modifier = Modifier.requiredSize(86.dp),
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                "PocketBoot",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold,
            )
            Text(
                "Rufus USB Formatting & ISO Suite",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        OutlinedButton(
            onClick = onToggleLogs,
            shape = RoundedCornerShape(12.dp),
        ) {
            Text(if (showLogs) "Hide Log" else "Log")
        }
    }
}

// ------------------------------------------------------------------ cards

@Composable
private fun StepCard(step: String, title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        step,
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                    )
                }
                Spacer(Modifier.width(10.dp))
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            content()
        }
    }
}

@Composable
private fun DrivePropertiesCard(
    state: UiState,
    busy: Boolean,
    viewModel: MainViewModel,
) {
    val cfg = state.config
    StepCard("1", "Drive Properties (Device)") {
        if (state.drives.isEmpty()) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text("🔌", fontSize = 28.sp)
                Column(Modifier.weight(1f)) {
                    Text(
                        "No USB drive detected",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        "Plug a pendrive into your phone via OTG adapter. It will appear automatically.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
            }
        } else {
            state.drives.forEach { drive ->
                DriveRow(
                    drive = drive,
                    selected = drive.id == state.selectedDriveId,
                    showRadio = state.drives.size > 1,
                    enabled = !busy,
                    onSelect = viewModel::selectDrive,
                    onGrant = viewModel::grantAccess,
                )
            }
        }

        // Expandable "Show advanced drive properties" like Rufus
        Text(
            text = if (cfg.showAdvancedDriveProps) "▾ Hide advanced drive properties" else "▸ Show advanced drive properties",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .clickable(enabled = !busy) { viewModel.toggleAdvancedDriveProps() }
                .padding(vertical = 2.dp),
        )

        if (cfg.showAdvancedDriveProps) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                RufusCheckboxRow(
                    label = "List USB Hard Drives",
                    checked = cfg.listUsbHardDrives,
                    enabled = !busy,
                    onCheckedChange = viewModel::setListUsbHardDrives,
                )
                RufusCheckboxRow(
                    label = "Add fixes for old BIOSes (extra partition, align, etc.)",
                    checked = cfg.addFixesForOldBios,
                    enabled = !busy,
                    onCheckedChange = viewModel::setAddFixesForOldBios,
                )
                RufusCheckboxRow(
                    label = "Use Rufus MBR with BIOS ID",
                    checked = cfg.useRufusMbr,
                    enabled = !busy,
                    onCheckedChange = viewModel::setUseRufusMbr,
                )
                if (cfg.useRufusMbr) {
                    RufusDropdown(
                        label = "BIOS ID",
                        selectedOption = cfg.biosId,
                        options = RufusConfig.biosIds,
                        enabled = !busy,
                        onOptionSelected = viewModel::setBiosId,
                    )
                }
            }
        }
    }
}

@Composable
private fun DriveRow(
    drive: DriveItem,
    selected: Boolean,
    showRadio: Boolean,
    enabled: Boolean,
    onSelect: (String) -> Unit,
    onGrant: (String) -> Unit,
) {
    val background =
        if (selected) MaterialTheme.colorScheme.primaryContainer
        else MaterialTheme.colorScheme.surfaceVariant
    val capacity = drive.capacityBytes
    val subtitle = when {
        !drive.hasPermission -> "Allow USB access to continue"
        capacity != null -> formatBytes(capacity)
        drive.error != null -> drive.error
        else -> "Reading drive…"
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(background)
            .clickable(enabled = enabled) { onSelect(drive.id) }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("💾", fontSize = 26.sp)
        Column(Modifier.weight(1f)) {
            Text(
                drive.name,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = if (drive.error != null && capacity == null) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (!drive.hasPermission) {
            TextButton(onClick = { onGrant(drive.id) }) { Text("Allow") }
        } else if (showRadio) {
            RadioButton(selected = selected, onClick = null)
        }
    }
}

@Composable
private fun BootAndPartitionCard(
    state: UiState,
    busy: Boolean,
    viewModel: MainViewModel,
    onPickIso: () -> Unit,
) {
    val cfg = state.config
    val iso = state.iso

    StepCard("2", "Boot Selection & Partitioning") {
        // Boot selection dropdown
        RufusDropdown(
            label = "Boot selection",
            selectedOption = cfg.bootSelection,
            options = RufusConfig.bootSelections,
            enabled = !busy,
            onOptionSelected = viewModel::setBootSelection,
        )

        // ISO picker and ISO-specific Rufus configurations
        if (cfg.bootSelection == RufusConfig.BOOT_ISO) {
            if (iso == null) {
                FilledTonalButton(
                    onClick = onPickIso,
                    enabled = !busy,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                ) {
                    Text("💿  SELECT (.iso / .img)", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                }
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(12.dp),
                ) {
                    Text("💿", fontSize = 26.sp)
                    Column(Modifier.weight(1f)) {
                        Text(
                            iso.name,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                        val meta = buildString {
                            append(formatBytes(iso.size))
                            if (iso.volumeId.isNotBlank()) append(" • Vol: ${iso.volumeId}")
                            if (iso.files.isNotEmpty()) append(" • ${iso.files.size} files")
                        }
                        Text(
                            meta,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    TextButton(onClick = onPickIso, enabled = !busy) { Text("SELECT") }
                }
            }

            state.isoNote?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }

            // Image option (Standard / DD / Windows To Go)
            RufusDropdown(
                label = "Image option",
                selectedOption = cfg.imageOption,
                options = RufusConfig.imageOptions,
                enabled = !busy,
                onOptionSelected = viewModel::setImageOption,
            )

            // Persistent partition size slider
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        "Persistent partition size",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        if (cfg.persistenceGb == 0) "0 GB (No persistence)" else "${cfg.persistenceGb} GB",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                Slider(
                    value = cfg.persistenceGb.toFloat(),
                    onValueChange = { viewModel.setPersistenceGb(it.roundToInt()) },
                    valueRange = 0f..32f,
                    steps = 31,
                    enabled = !busy,
                )
            }
        }

        // Partition Scheme & Target System side by side
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Box(modifier = Modifier.weight(0.45f)) {
                RufusDropdown(
                    label = "Partition scheme",
                    selectedOption = cfg.partitionScheme,
                    options = RufusConfig.partitionSchemes,
                    enabled = !busy,
                    onOptionSelected = viewModel::setPartitionScheme,
                )
            }
            Box(modifier = Modifier.weight(0.55f)) {
                RufusDropdown(
                    label = "Target system",
                    selectedOption = cfg.targetSystem,
                    options = RufusConfig.targetSystems,
                    enabled = !busy,
                    onOptionSelected = viewModel::setTargetSystem,
                )
            }
        }
    }
}

@Composable
private fun FormatOptionsCard(
    state: UiState,
    busy: Boolean,
    viewModel: MainViewModel,
) {
    val cfg = state.config

    StepCard("3", "Format Options") {
        OutlinedTextField(
            value = cfg.volumeLabel,
            onValueChange = viewModel::setVolumeLabel,
            label = { Text("Volume label") },
            singleLine = true,
            enabled = !busy,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth(),
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Box(modifier = Modifier.weight(0.5f)) {
                RufusDropdown(
                    label = "File system",
                    selectedOption = cfg.fileSystem,
                    options = RufusConfig.fileSystems,
                    enabled = !busy,
                    onOptionSelected = viewModel::setFileSystem,
                )
            }
            Box(modifier = Modifier.weight(0.5f)) {
                RufusDropdown(
                    label = "Cluster size",
                    selectedOption = cfg.clusterSize,
                    options = RufusConfig.clusterSizes,
                    enabled = !busy,
                    onOptionSelected = viewModel::setClusterSize,
                )
            }
        }

        Text(
            text = if (cfg.showAdvancedFormatOptions) "▾ Hide advanced format options" else "▸ Show advanced format options",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .clickable(enabled = !busy) { viewModel.toggleAdvancedFormatOptions() }
                .padding(vertical = 2.dp),
        )

        if (cfg.showAdvancedFormatOptions) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                RufusCheckboxRow(
                    label = "Quick format",
                    checked = cfg.quickFormat,
                    enabled = !busy,
                    onCheckedChange = viewModel::setQuickFormat,
                )
                RufusCheckboxRow(
                    label = "Create extended label and icon files",
                    checked = cfg.createExtendedLabel,
                    enabled = !busy,
                    onCheckedChange = viewModel::setCreateExtendedLabel,
                )
                RufusCheckboxRow(
                    label = "Check device for bad blocks",
                    checked = cfg.checkBadBlocks,
                    enabled = !busy,
                    onCheckedChange = viewModel::setCheckBadBlocks,
                )
                if (cfg.checkBadBlocks) {
                    RufusDropdown(
                        label = "Bad block passes",
                        selectedOption = cfg.badBlockPasses,
                        options = RufusConfig.badBlockPassList,
                        enabled = !busy,
                        onOptionSelected = viewModel::setBadBlockPasses,
                    )
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Live Log Viewer

@Composable
private fun LogViewerCard(
    logs: List<String>,
    onClear: () -> Unit,
    onClose: () -> Unit,
) {
    val listState = rememberLazyListState()
    val clipboard = LocalClipboardManager.current

    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.lastIndex)
        }
    }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B0F19)),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF2E364F), RoundedCornerShape(18.dp)),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    "Rufus Process Log (${logs.size})",
                    color = Color(0xFFE2E8F0),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(
                        onClick = {
                            clipboard.setText(AnnotatedString(logs.joinToString("\n")))
                        },
                    ) {
                        Text("Copy", color = Color(0xFF93C5FD), fontSize = 12.sp)
                    }
                    TextButton(onClick = onClear) {
                        Text("Clear", color = Color(0xFFFCA5A5), fontSize = 12.sp)
                    }
                    TextButton(onClick = onClose) {
                        Text("Close", color = Color(0xFFCBD5E1), fontSize = 12.sp)
                    }
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF060911))
                    .padding(10.dp),
            ) {
                if (logs.isEmpty()) {
                    Text(
                        "No log entries yet.",
                        color = Color(0xFF64748B),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                    )
                } else {
                    LazyColumn(
                        state = listState,
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        items(logs) { line ->
                            Text(
                                text = line,
                                color = Color(0xFF86EFAC),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.5.sp,
                                lineHeight = 15.sp,
                            )
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ start / progress / result

@Composable
private fun ActionArea(
    state: UiState,
    onStart: () -> Unit,
    onCancel: () -> Unit,
    onReset: () -> Unit,
    onToggleLogs: () -> Unit,
) {
    when (val write = state.write) {
        is WriteState.Running -> ProgressCard(
            write = write,
            showLogs = state.showLogs,
            onToggleLogs = onToggleLogs,
            onCancel = onCancel,
        )
        is WriteState.Success -> ResultCard(
            emoji = "✅",
            title = "Your bootable drive is ready",
            message = "Safely unplug it, then boot your computer from it (open the boot menu when the PC starts).",
            buttonLabel = "Done",
            showLogs = state.showLogs,
            onToggleLogs = onToggleLogs,
            onClick = onReset,
        )
        is WriteState.Failed -> ResultCard(
            emoji = "⚠️",
            title = "Something went wrong",
            message = write.message,
            buttonLabel = "Back",
            showLogs = state.showLogs,
            onToggleLogs = onToggleLogs,
            onClick = onReset,
        )
        is WriteState.Cancelled -> ResultCard(
            emoji = "⏹️",
            title = "Cancelled",
            message = "The drive is only partly written and won't boot. Start again to finish.",
            buttonLabel = "OK",
            showLogs = state.showLogs,
            onToggleLogs = onToggleLogs,
            onClick = onReset,
        )
        is WriteState.Idle -> {
            val blocker = state.blocker
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth(),
            ) {
                // Rufus-style status bar when idle
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(38.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF1E293B)),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = blocker ?: "READY — Click START to format and write",
                        color = Color(0xFFE2E8F0),
                        fontWeight = FontWeight.Light,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 12.dp),
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    OutlinedButton(
                        onClick = onToggleLogs,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(0.35f)
                            .height(56.dp),
                    ) {
                        Text(
                            if (state.showLogs) "HIDE LOG" else "LOG",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }

                    Button(
                        onClick = onStart,
                        enabled = blocker == null,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(0.65f)
                            .height(56.dp),
                    ) {
                        Text("START", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProgressCard(
    write: WriteState.Running,
    showLogs: Boolean,
    onToggleLogs: () -> Unit,
    onCancel: () -> Unit,
) {
    val progress =
        if (write.totalBytes > 0) (write.writtenBytes.toFloat() / write.totalBytes).coerceIn(0f, 1f) else 0f
    val pct = (progress * 100).toInt()
    val finishing = write.writtenBytes >= write.totalBytes && write.totalBytes > 0
    val remaining = (write.totalBytes - write.writtenBytes).coerceAtLeast(0L)
    val eta =
        if (write.bytesPerSecond > 0 && !finishing) " • " + formatDuration(remaining / write.bytesPerSecond) + " left"
        else ""

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                if (finishing) "Finalizing drive…" else "Writing to USB… $pct%",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )

            // Percentage Bar with overlaid Light Letters showing what is being copied
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF1E293B)),
                contentAlignment = Alignment.Center,
            ) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF4F46E5),
                    trackColor = Color(0xFF1E293B),
                )
                Text(
                    text = "$pct% — ${write.currentItem}",
                    color = Color(0xFFF8FAFC),
                    fontWeight = FontWeight.Light,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
            }

            Text(
                formatBytes(write.writtenBytes) + " of " + formatBytes(write.totalBytes) +
                    " • " + formatBytes(write.bytesPerSecond) + "/s" + eta,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "Keep the app open and do not unplug the USB drive.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedButton(
                    onClick = onToggleLogs,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    Text(if (showLogs) "Hide Log" else "Log")
                }
                OutlinedButton(
                    onClick = onCancel,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    Text("Cancel")
                }
            }
        }
    }
}

@Composable
private fun ResultCard(
    emoji: String,
    title: String,
    message: String,
    buttonLabel: String,
    showLogs: Boolean,
    onToggleLogs: () -> Unit,
    onClick: () -> Unit,
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(emoji, fontSize = 38.sp)
            Text(
                title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                textAlign = TextAlign.Center,
            )
            Text(
                message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                textAlign = TextAlign.Center,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = onToggleLogs,
                    shape = RoundedCornerShape(14.dp),
                ) {
                    Text(if (showLogs) "Hide Log" else "Log")
                }
                Button(onClick = onClick, shape = RoundedCornerShape(14.dp)) {
                    Text(buttonLabel)
                }
            }
        }
    }
}

@Composable
private fun InfoNote() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(14.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("ℹ️", fontSize = 18.sp)
        Text(
            "Supports Rufus Partition Schemes (MBR/GPT), Target Systems (BIOS/UEFI), File Systems, Cluster Sizes, " +
                "and direct USB OTG block writing with live file progress and process logging.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

// ------------------------------------------------------------------ Reusable Rufus Controls

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RufusDropdown(
    label: String,
    selectedOption: String,
    options: List<String>,
    enabled: Boolean,
    onOptionSelected: (String) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }

    ExposedDropdownMenuBox(
        expanded = expanded && enabled,
        onExpandedChange = { if (enabled) expanded = !expanded },
    ) {
        OutlinedTextField(
            value = selectedOption,
            onValueChange = {},
            readOnly = true,
            enabled = enabled,
            singleLine = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded && enabled) },
            colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth(),
        )
        ExposedDropdownMenu(
            expanded = expanded && enabled,
            onDismissRequest = { expanded = false },
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        onOptionSelected(option)
                        expanded = false
                    },
                )
            }
        }
    }
}

@Composable
private fun RufusCheckboxRow(
    label: String,
    checked: Boolean,
    enabled: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(enabled = enabled) { onCheckedChange(!checked) }
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled,
        )
        Spacer(Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}

// ------------------------------------------------------------------ Warning Confirm Dialog

@Composable
private fun ConfirmDialog(state: UiState, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val drive = state.selectedDrive
    val capacity = drive?.capacityBytes?.let { " (" + formatBytes(it) + ")" } ?: ""
    val driveTitle = (drive?.name ?: "your pendrive") + capacity

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "WARNING: Format & Erase Pendrive?",
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.error,
            )
        },
        text = {
                    Text(
            "WARNING: All data on $driveTitle will be formatted and permanently removed!\n\n" +
                "Partition Scheme: ${state.config.partitionScheme} (${state.config.targetSystem})\n" +
                "File System: ${state.config.fileSystem}\n\n" +
                "Click Confirm to format and continue, or Cancel to abort."
        )
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
            ) {
                Text("Confirm", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
    )
}
