package com.pocketboot.app

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.pocketboot.app.ui.MainScreen
import com.pocketboot.app.ui.PocketBootTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val pickIso = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.onIsoPicked(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Automatic drive detection: look for plugged-in USB drives while the app is visible.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    viewModel.refreshDrives()
                    delay(1000)
                }
            }
        }

        setContent {
            PocketBootTheme {
                val state by viewModel.state.collectAsStateWithLifecycle()

                // Don't let the screen sleep while a long write is running.
                val writing = state.write is WriteState.Running
                DisposableEffect(writing) {
                    if (writing) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    onDispose { window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
                }

                MainScreen(
                    state = state,
                    onPickIso = { pickIso.launch(arrayOf("*/*")) },
                    onSelectDrive = viewModel::selectDrive,
                    onGrantAccess = viewModel::grantAccess,
                    onStart = viewModel::requestStart,
                    onConfirm = viewModel::confirmStart,
                    onDismissConfirm = viewModel::dismissConfirm,
                    onCancel = viewModel::cancelWriting,
                    onReset = viewModel::resetResult,
                )
            }
        }
    }
}
