package com.pocketboot.app

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import java.io.Closeable
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** A SCSI command was rejected by the drive (no media, write protected, ...). */
class ScsiException(message: String) : IOException(message)

/**
 * Minimal USB "Bulk-Only Transport" mass-storage driver.
 * Talks raw SCSI (INQUIRY, READ CAPACITY, WRITE(10)) straight to the flash drive,
 * so no root access is needed. This is what lets us write a disk image block by block.
 */
class UsbMassStorage private constructor(
    private val connection: UsbDeviceConnection,
    private val usbInterface: UsbInterface,
    private val inEndpoint: UsbEndpoint,
    private val outEndpoint: UsbEndpoint,
) : Closeable {

    var blockSize: Int = 512
        private set
    var blockCount: Long = 0
        private set
    var label: String = ""
        private set

    val capacityBytes: Long get() = blockCount * blockSize

    private var nextTag = 1

    // ---------------------------------------------------------------- public API

    /** Writes [blocks] blocks from [data] (starting at [offset]) to [lba]. */
    fun write(lba: Long, data: ByteArray, offset: Int, blocks: Int) {
        require(blocks in 1..0xFFFF) { "Invalid block count" }
        val cdb = ByteArray(10)
        cdb[0] = 0x2A // WRITE(10)
        cdb[2] = (lba shr 24).toByte()
        cdb[3] = (lba shr 16).toByte()
        cdb[4] = (lba shr 8).toByte()
        cdb[5] = lba.toByte()
        cdb[7] = (blocks shr 8).toByte()
        cdb[8] = blocks.toByte()
        val length = blocks * blockSize
        val done = execute(cdb, length, false, data, offset)
        if (done != length) throw IOException("The USB drive did not accept all data")
    }

    /** Asks the drive to commit its internal write cache to flash. */
    fun flush() {
        try {
            execute(CDB_SYNC_CACHE, 0, false, null, 0)
        } catch (e: ScsiException) {
            // Some drives don't implement SYNCHRONIZE CACHE; that's fine.
        }
    }

    override fun close() {
        try {
            connection.releaseInterface(usbInterface)
        } catch (e: Exception) {
            // ignore
        }
        connection.close()
    }

    // ---------------------------------------------------------------- setup

    private fun initialize() {
        // Drive name (INQUIRY)
        try {
            val buf = ByteArray(36)
            execute(byteArrayOf(0x12, 0, 0, 0, 36, 0), 36, true, buf, 0)
            val vendor = ascii(buf, 8, 8)
            val product = ascii(buf, 16, 16)
            label = "$vendor $product".trim()
        } catch (e: ScsiException) {
            // not important
        }

        // Wait until the drive says it is ready (many drives need a moment after plugging in)
        for (attempt in 1..15) {
            try {
                execute(CDB_TEST_UNIT_READY, 0, false, null, 0)
                break
            } catch (e: ScsiException) {
                Thread.sleep(300)
            }
        }

        // Capacity (READ CAPACITY(10))
        val cap = ByteArray(8)
        execute(byteArrayOf(0x25, 0, 0, 0, 0, 0, 0, 0, 0, 0), 8, true, cap, 0)
        val bb = ByteBuffer.wrap(cap).order(ByteOrder.BIG_ENDIAN)
        val lastLba = bb.int.toLong() and 0xFFFFFFFFL
        val size = bb.int
        if (size <= 0) throw IOException("The drive reported an invalid block size")
        if (lastLba == 0xFFFFFFFFL) throw IOException("Drives larger than 2 TB are not supported")
        blockCount = lastLba + 1
        blockSize = size
    }

    private fun ascii(buf: ByteArray, offset: Int, length: Int): String {
        val sb = StringBuilder()
        for (i in offset until offset + length) {
            val c = buf[i].toInt() and 0xFF
            if (c in 32..126) sb.append(c.toChar())
        }
        return sb.toString().trim()
    }

    // ---------------------------------------------------------------- protocol

    /**
     * Runs one SCSI command: CBW -> optional data phase -> CSW.
     * Returns the number of data bytes transferred.
     */
    private fun execute(
        cdb: ByteArray,
        dataLength: Int,
        dataIn: Boolean,
        buffer: ByteArray?,
        offset: Int,
        readSense: Boolean = true,
    ): Int {
        val tag = nextTag++

        // Command Block Wrapper
        val cbw = ByteBuffer.allocate(CBW_SIZE).order(ByteOrder.LITTLE_ENDIAN)
        cbw.putInt(CBW_SIGNATURE)
        cbw.putInt(tag)
        cbw.putInt(dataLength)
        cbw.put(if (dataIn) 0x80.toByte() else 0x00.toByte())
        cbw.put(0.toByte()) // LUN 0
        cbw.put(cdb.size.toByte())
        cbw.put(cdb)

        val sent = connection.bulkTransfer(outEndpoint, cbw.array(), CBW_SIZE, COMMAND_TIMEOUT_MS)
        if (sent != CBW_SIZE) {
            resetRecovery()
            throw IOException("The USB drive stopped responding")
        }

        // Data phase
        var transferred = 0
        if (dataLength > 0 && buffer != null) {
            val endpoint = if (dataIn) inEndpoint else outEndpoint
            while (transferred < dataLength) {
                val chunk = minOf(MAX_CHUNK, dataLength - transferred)
                val n = connection.bulkTransfer(endpoint, buffer, offset + transferred, chunk, DATA_TIMEOUT_MS)
                if (n < 0) {
                    clearHalt(endpoint)
                    break
                }
                if (n == 0) break
                transferred += n
                if (dataIn && n < chunk) break
            }
        }

        // Command Status Wrapper
        val csw = ByteArray(CSW_SIZE)
        var got = connection.bulkTransfer(inEndpoint, csw, CSW_SIZE, COMMAND_TIMEOUT_MS)
        if (got != CSW_SIZE) {
            clearHalt(inEndpoint)
            got = connection.bulkTransfer(inEndpoint, csw, CSW_SIZE, COMMAND_TIMEOUT_MS)
        }
        if (got != CSW_SIZE) {
            resetRecovery()
            throw IOException("The USB drive stopped responding (was it unplugged?)")
        }
        val bb = ByteBuffer.wrap(csw).order(ByteOrder.LITTLE_ENDIAN)
        val signature = bb.getInt(0)
        val replyTag = bb.getInt(4)
        val status = csw[12].toInt() and 0xFF
        if (signature != CSW_SIGNATURE || replyTag != tag) {
            resetRecovery()
            throw IOException("Invalid reply from the USB drive")
        }
        if (status == 0) return transferred
        if (status == 1) throw failure(readSense)
        resetRecovery()
        throw IOException("USB protocol error")
    }

    private fun failure(readSense: Boolean): ScsiException {
        if (readSense) {
            try {
                val buf = ByteArray(18)
                execute(byteArrayOf(0x03, 0, 0, 0, 18, 0), 18, true, buf, 0, readSense = false)
                val key = buf[2].toInt() and 0x0F
                val asc = buf[12].toInt() and 0xFF
                return ScsiException(describeSense(key, asc))
            } catch (e: IOException) {
                // fall through
            }
        }
        return ScsiException("The USB drive rejected the command")
    }

    private fun describeSense(key: Int, asc: Int): String {
        val code = String.format("%02X", asc)
        return when {
            asc == 0x3A -> "No media in the drive"
            key == 7 || asc == 0x27 -> "The drive is write-protected"
            key == 3 -> "The drive reported a medium error"
            key == 2 -> "The drive is not ready"
            key == 6 -> "The drive was reset"
            else -> "The drive reported an error (key $key, code $code)"
        }
    }

    private fun clearHalt(endpoint: UsbEndpoint) {
        // CLEAR_FEATURE(ENDPOINT_HALT)
        connection.controlTransfer(0x02, 0x01, 0, endpoint.address, null, 0, COMMAND_TIMEOUT_MS)
    }

    private fun resetRecovery() {
        // Bulk-Only Mass Storage Reset, then clear both endpoints
        connection.controlTransfer(0x21, 0xFF, 0, usbInterface.id, null, 0, COMMAND_TIMEOUT_MS)
        clearHalt(inEndpoint)
        clearHalt(outEndpoint)
    }

    companion object {
        private const val CBW_SIGNATURE = 0x43425355 // "USBC"
        private const val CSW_SIGNATURE = 0x53425355 // "USBS"
        private const val CBW_SIZE = 31
        private const val CSW_SIZE = 13
        private const val MAX_CHUNK = 16 * 1024
        private const val COMMAND_TIMEOUT_MS = 5_000
        private const val DATA_TIMEOUT_MS = 30_000

        private val CDB_TEST_UNIT_READY = ByteArray(6)
        private val CDB_SYNC_CACHE = byteArrayOf(0x35, 0, 0, 0, 0, 0, 0, 0, 0, 0)

        private fun findInterface(device: UsbDevice): UsbInterface? {
            for (i in 0 until device.interfaceCount) {
                val intf = device.getInterface(i)
                if (intf.interfaceClass == UsbConstants.USB_CLASS_MASS_STORAGE &&
                    intf.interfaceProtocol == 0x50 // bulk-only transport
                ) return intf
            }
            return null
        }

        fun isMassStorage(device: UsbDevice): Boolean = findInterface(device) != null

        /** Opens the drive (permission must already be granted). */
        fun open(manager: UsbManager, device: UsbDevice): UsbMassStorage {
            val intf = findInterface(device)
                ?: throw IOException("This USB device is not a storage drive")

            var inEp: UsbEndpoint? = null
            var outEp: UsbEndpoint? = null
            for (i in 0 until intf.endpointCount) {
                val ep = intf.getEndpoint(i)
                if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                    if (ep.direction == UsbConstants.USB_DIR_IN) inEp = ep else outEp = ep
                }
            }
            if (inEp == null || outEp == null) throw IOException("The drive has no usable USB endpoints")

            val conn = manager.openDevice(device) ?: throw IOException("Could not open the USB drive")
            if (!conn.claimInterface(intf, true)) {
                conn.close()
                throw IOException("Could not take control of the USB drive")
            }
            val storage = UsbMassStorage(conn, intf, inEp, outEp)
            try {
                storage.initialize()
            } catch (e: Exception) {
                storage.close()
                throw e
            }
            return storage
        }
    }
}
