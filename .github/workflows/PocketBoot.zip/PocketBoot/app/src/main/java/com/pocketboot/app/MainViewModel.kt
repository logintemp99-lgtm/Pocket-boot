package com.pocketboot.app

import android.app.Application
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val usbManager = application.getSystemService(Context.USB_SERVICE) as UsbManager

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private class Probe(
        val capacity: Long?,
        val label: String?,
        val error: String?,
        val at: Long,
    )

    private val probes = HashMap<String, Probe>()
    private val permissionAsked = HashSet<String>()
    private val usbLock = Mutex()
    private var writeJob: Job? = null

    // ------------------------------------------------------------ drive detection

    /** Called every second or so while the app is on screen. */
    suspend fun refreshDrives() {
        try {
            val devices = usbManager.deviceList.values.filter { UsbMassStorage.isMassStorage(it) }
            val ids = devices.map { it.deviceName }.toSet()
            probes.keys.retainAll(ids)
            permissionAsked.retainAll(ids)

            val busy = _state.value.write is WriteState.Running
            val items = ArrayList<DriveItem>()
            for (device in devices) {
                val id = device.deviceName
                val permitted = usbManager.hasPermission(device)
                if (!permitted && permissionAsked.add(id)) requestPermission(device)

                if (permitted && !busy) {
                    val old = probes[id]
                    val stale = old == null ||
                        (old.error != null && SystemClock.elapsedRealtime() - old.at > 4_000)
                    if (stale) {
                        probes[id] = withContext(Dispatchers.IO) {
                            usbLock.withLock { probe(device) }
                        }
                    }
                }
                val p = probes[id]
                items.add(DriveItem(id, driveName(device, p), permitted, p?.capacity, p?.error))
            }

            _state.update { s ->
                val selected =
                    if (items.any { it.id == s.selectedDriveId }) s.selectedDriveId
                    else items.firstOrNull()?.id
                if (s.drives == items && s.selectedDriveId == selected) s
                else s.copy(drives = items, selectedDriveId = selected)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // Never let a USB hiccup crash the polling loop.
        }
    }

    private fun probe(device: UsbDevice): Probe {
        return try {
            UsbMassStorage.open(usbManager, device).use {
                Probe(it.capacityBytes, it.label, null, SystemClock.elapsedRealtime())
            }
        } catch (e: Exception) {
            Probe(null, null, e.message ?: "Could not read the drive", SystemClock.elapsedRealtime())
        }
    }

    private fun driveName(device: UsbDevice, probe: Probe?): String {
        val scsi = probe?.label?.takeIf { it.isNotBlank() }
        if (scsi != null) return scsi
        // On Android 10+ the product name is only readable once permission is granted.
        val product = runCatching { device.productName }.getOrNull()?.takeIf { it.isNotBlank() }
        return product ?: "USB drive"
    }

    private fun requestPermission(device: UsbDevice) {
        val app = getApplication<Application>()
        val intent = Intent(ACTION_USB_PERMISSION).setPackage(app.packageName)
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
        val pending = PendingIntent.getBroadcast(app, 0, intent, flags)
        usbManager.requestPermission(device, pending)
    }

    /** The "Allow" button: ask Android for access to the drive again. */
    fun grantAccess(driveId: String) {
        val device = usbManager.deviceList.values.firstOrNull { it.deviceName == driveId } ?: return
        requestPermission(device)
    }

    fun selectDrive(id: String) {
        _state.update { it.copy(selectedDriveId = id) }
    }

    // ------------------------------------------------------------ ISO picking

    fun onIsoPicked(uri: Uri) {
        viewModelScope.launch {
            val info = withContext(Dispatchers.IO) {
                runCatching { IsoWriter.queryInfo(getApplication(), uri) }.getOrNull()
            }
            _state.update { s ->
                when {
                    info == null || info.size <= 0 -> s.copy(
                        iso = null,
                        isoUri = null,
                        isoNote = "Couldn't read this file. Try picking it from your Downloads folder.",
                    )
                    else -> {
                        val lower = info.name.lowercase()
                        val looksRight = lower.endsWith(".iso") || lower.endsWith(".img")
                        s.copy(
                            iso = info,
                            isoUri = uri,
                            isoNote = if (looksRight) null else "This doesn't look like an .iso file. Double-check it.",
                        )
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ writing

    fun requestStart() {
        if (_state.value.blocker == null) {
            _state.update { it.copy(showConfirm = true) }
        }
    }

    fun dismissConfirm() {
        _state.update { it.copy(showConfirm = false) }
    }

    fun confirmStart() {
        _state.update { it.copy(showConfirm = false) }
        startWriting()
    }

    fun cancelWriting() {
        writeJob?.cancel()
    }

    fun resetResult() {
        _state.update { it.copy(write = WriteState.Idle) }
    }

    private fun startWriting() {
        val s = _state.value
        val drive = s.selectedDrive ?: return
        val iso = s.iso ?: return
        val uri = s.isoUri ?: return
        val device = usbManager.deviceList.values.firstOrNull { it.deviceName == drive.id }
        if (device == null) {
            _state.update { it.copy(write = WriteState.Failed("The drive was unplugged.")) }
            return
        }

        writeJob = viewModelScope.launch {
            _state.update { it.copy(write = WriteState.Running(0, iso.size, 0)) }
            try {
                withContext(Dispatchers.IO) {
                    usbLock.withLock {
                        UsbMassStorage.open(usbManager, device).use { storage ->
                            var lastUiUpdate = 0L
                            var speedTime = SystemClock.elapsedRealtime()
                            var speedBytes = 0L
                            var speed = 0L
                            IsoWriter.write(getApplication(), uri, iso.size, storage) { written ->
                                val now = SystemClock.elapsedRealtime()
                                if (now - speedTime >= 1000) {
                                    speed = (written - speedBytes) * 1000 / (now - speedTime)
                                    speedBytes = written
                                    speedTime = now
                                }
                                if (now - lastUiUpdate >= 250) {
                                    lastUiUpdate = now
                                    _state.update {
                                        it.copy(write = WriteState.Running(written, iso.size, speed))
                                    }
                                }
                            }
                        }
                    }
                }
                _state.update { it.copy(write = WriteState.Success) }
            } catch (e: CancellationException) {
                _state.update { it.copy(write = WriteState.Cancelled) }
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(write = WriteState.Failed(friendly(e))) }
            } finally {
                probes.remove(drive.id) // re-read the drive afterwards
            }
        }
    }

    private fun friendly(e: Exception): String = when (e) {
        is SecurityException -> "Access to the drive was lost. Unplug it, plug it back in and allow access."
        else -> e.message ?: "Something went wrong while writing."
    }

    private companion object {
        const val ACTION_USB_PERMISSION = "com.pocketboot.app.USB_PERMISSION"
    }
}
