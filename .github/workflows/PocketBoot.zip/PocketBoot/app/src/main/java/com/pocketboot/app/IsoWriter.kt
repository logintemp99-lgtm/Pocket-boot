package com.pocketboot.app

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.IOException
import java.io.InputStream
import java.util.Arrays

data class IsoInfo(val name: String, val size: Long)

object IsoWriter {

    private const val CHUNK_BYTES = 256 * 1024

    /** Reads the file name and size of the picked document. */
    fun queryInfo(context: Context, uri: Uri): IsoInfo {
        var name = "image.iso"
        var size = -1L
        context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
            null, null, null,
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0 && !cursor.isNull(nameIndex)) name = cursor.getString(nameIndex)
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
            }
        }
        if (size <= 0) {
            try {
                context.contentResolver.openFileDescriptor(uri, "r")?.use { size = it.statSize }
            } catch (e: Exception) {
                // size stays unknown
            }
        }
        return IsoInfo(name, size)
    }

    /**
     * Copies the ISO byte for byte onto the drive, starting at block 0.
     * This is the same "DD image" mode Rufus uses for hybrid ISOs.
     */
    suspend fun write(
        context: Context,
        uri: Uri,
        isoSize: Long,
        storage: UsbMassStorage,
        onProgress: (Long) -> Unit,
    ) {
        if (isoSize > storage.capacityBytes) {
            throw IOException("The drive is smaller than the ISO file")
        }
        val blockSize = storage.blockSize
        val chunkBlocks = (CHUNK_BYTES / blockSize).coerceIn(1, 0xFFFF)
        val chunkBytes = chunkBlocks * blockSize
        val buffer = ByteArray(chunkBytes)

        val input = context.contentResolver.openInputStream(uri)
            ?: throw IOException("Could not open the ISO file")

        input.use { stream ->
            var lba = 0L
            var written = 0L
            while (true) {
                currentCoroutineContext().ensureActive()

                val read = readFully(stream, buffer)
                if (read <= 0) break

                val blocks = (read + blockSize - 1) / blockSize
                val padded = blocks * blockSize
                if (padded > read) Arrays.fill(buffer, read, padded, 0.toByte())

                storage.write(lba, buffer, 0, blocks)
                lba += blocks
                written += read
                onProgress(written)

                if (read < chunkBytes) break
            }
        }
        storage.flush()
    }

    private fun readFully(stream: InputStream, buffer: ByteArray): Int {
        var total = 0
        while (total < buffer.size) {
            val n = stream.read(buffer, total, buffer.size - total)
            if (n < 0) break
            total += n
        }
        return total
    }
}
